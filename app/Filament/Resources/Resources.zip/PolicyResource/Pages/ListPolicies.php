<?php

namespace App\Filament\Resources\PolicyResource\Pages;

use App\Filament\Resources\PolicyResource;
use App\Models\Installment;
use App\Models\Insurer;
use App\Models\Policy;
use App\Models\User;
use Carbon\Carbon;
use Filament\Actions;
use Filament\Forms;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class ListPolicies extends ListRecords
{
    protected static string $resource = PolicyResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),

            Actions\Action::make('importExcel')
                ->label('ورود گروهی از اکسل (CSV)')
                ->icon('heroicon-o-arrow-up-tray')
                ->color('success')
                ->form([
                    Forms\Components\FileUpload::make('csv_file')
                        ->label('فایل اکسل (فرمت CSV با ستون‌های: name, national_code, mobile, insurer, policy_number, title, total_amount, installments_count)')
                        ->acceptedFileTypes(['text/csv', 'text/plain', 'application/vnd.ms-excel'])
                        ->disk('local')
                        ->directory('imports')
                        ->required(),
                ])
                ->action(function (array $data): void {
                    $path = Storage::disk('local')->path($data['csv_file']);
                    if (! file_exists($path)) {
                        return;
                    }

                    $rows = array_map('str_getcsv', file($path));
                    $header = array_shift($rows);
                    $imported = 0;

                    foreach ($rows as $row) {
                        if (count($row) < 8) {
                            continue;
                        }
                        [$name, $nationalCode, $mobile, $insurerName, $policyNumber, $title, $totalAmount, $installmentsCount] = array_map('trim', $row);

                        if (! preg_match('/^09\d{9}$/', $mobile)) {
                            continue;
                        }

                        $user = User::firstOrCreate(
                            ['mobile' => $mobile],
                            [
                                'name' => $name,
                                'national_code' => $nationalCode,
                                'password' => Hash::make($nationalCode ?: '12345678'),
                            ]
                        );

                        $insurer = Insurer::firstOrCreate(['name' => $insurerName]);

                        $policy = Policy::updateOrCreate(
                            ['policy_number' => $policyNumber],
                            [
                                'user_id' => $user->id,
                                'insurer_id' => $insurer->id,
                                'title' => $title,
                                'issued_at' => now('Asia/Tehran')->toDateString(),
                                'expires_at' => now('Asia/Tehran')->addYear()->toDateString(),
                                'total_amount' => (int) $totalAmount,
                                'payment_type' => ((int) $installmentsCount > 0) ? 'installment' : 'cash',
                                'installments_count' => (int) $installmentsCount,
                                'first_due_date' => now('Asia/Tehran')->addMonth()->toDateString(),
                            ]
                        );

                        $count = (int) $installmentsCount;
                        if ($count > 0 && $policy->installments()->count() === 0) {
                            $perAmount = (int) floor(((int) $totalAmount) / $count);
                            for ($i = 1; $i <= $count; $i++) {
                                Installment::create([
                                    'policy_id' => $policy->id,
                                    'installment_number' => $i,
                                    'amount' => $perAmount,
                                    'due_date' => Carbon::now('Asia/Tehran')->addMonths($i)->toDateString(),
                                    'status' => 'pending',
                                ]);
                            }
                        }
                        $imported++;
                    }

                    Notification::make()
                        ->title("تعداد {$imported} بیمه‌نامه به همراه اقساط با موفقیت وارد شد.")
                        ->success()
                        ->send();
                }),
        ];
    }
}